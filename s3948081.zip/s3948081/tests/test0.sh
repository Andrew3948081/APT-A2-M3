#! /usr/bin/bash
./ppd > tests/test0.actual_ppd_output