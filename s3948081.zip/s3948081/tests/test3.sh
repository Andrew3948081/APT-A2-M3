#! /usr/bin/bash
./ppd stock.dat coins.dat < tests/test3.input > tests/test3.actual_ppd_output