#! /usr/bin/bash
./ppd stock.dat coins.dat < tests/test2.input > tests/test2.actual_ppd_output