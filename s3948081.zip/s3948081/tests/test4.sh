#! /usr/bin/bash
./ppd stock.dat coins.dat < tests/test4.input > tests/test4.actual_ppd_output