#! /usr/bin/bash
./ppd stock.dat coins.dat < tests/test8.input > tests/test8.actual_ppd_output