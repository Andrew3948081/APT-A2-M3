#! /usr/bin/bash
./ppd stock.dat coins.dat < tests/test5.input > tests/test5.actual_ppd_output