#! /usr/bin/bash
./ppd stock.dat coins.dat < tests/test7.input > tests/test7.actual_ppd_output