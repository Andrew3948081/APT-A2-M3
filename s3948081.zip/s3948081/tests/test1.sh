#! /usr/bin/bash
./ppd 1 1 < tests/test1.input > tests/test1.actual_ppd_output