#! /usr/bin/bash
./ppd stock.dat coins.dat < tests/test6.input > tests/test6.actual_ppd_output